package com.cpe.springboot.store;

public enum StoreAction {
	BUY,SELL
}
